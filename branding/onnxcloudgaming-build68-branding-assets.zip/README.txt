# ONNXCloudGaming Build 68 branding assets

These assets are prepared from the exact red/black ONN + green Xbox X artwork supplied in chat.

- `app/src/main/res/drawable-nodpi/onn_splash.png`: 1920x1080 landscape splash artwork.
- `app/src/main/res/mipmap-*/ic_launcher.png`: launcher icon sizes for Android density buckets.

The app manifest already references `@mipmap/ic_launcher`. To show the splash image at launch,
the Android app theme must set its window background to `@drawable/onn_splash` (or the app's
existing splash implementation must reference that drawable). Preserve all existing app
activities, streaming code, settings, and controller behavior.
